# Mods installed

fabric-api
waystones
xaeros-minimap
farmers-delight
lootr
euphoria-patches
artifacts
chat-heads
indium
Marium's Soulslike Weaponry
Dungeons and Taverns    